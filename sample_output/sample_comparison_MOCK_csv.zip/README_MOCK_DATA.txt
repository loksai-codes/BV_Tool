MOCK DATA — generated from test fixtures, NOT from Power BI
